let gameSeq = [];
let userSeq = [];
let btns= ["yellow", 'green', 'purple', 'red'];
let started=false;
let level=0;
let h2= document.querySelector('h2');
document.addEventListener("keypress", function(){
    if(started==false){
        levelUp();
        started=true;
        console.log('level stared');
    }
});

function levelUp(){
    userSeq= [];
    level++;
    h2.innerText=`Level ${level}`;

    //random btn choose
    let randINX= Math.floor(Math.random() *4);
    let randColor= btns[randINX];
    let randBtn= document.querySelector(`.${randColor}`);
    gameSeq.push(randColor)
    flash(randBtn);
}

function flash(btn){
    btn.classList.add("flash");
    setTimeout(function(){
        btn.classList.remove("flash");}, 250);
}

function check(idx){
    if(userSeq[idx]===gameSeq[idx]){
        if(userSeq.length==gameSeq.length){
            setTimeout(levelUp(), 500);
        }
    }
    else{
        h2.innerHTML=`Game Over! Your score was <b>${level}</b> <br>Press any key to start`;
        document.querySelector("body").style.backgroundColor= 'red';
        setTimeout(function(){
            document.querySelector("body").style.backgroundColor= 'white'; 
        }, 150); 
        started=false;
        gameSeq=[];
        userSeq= [];
        level=0;
    }
}

function btnPress(){
   let btn= this;
   flash(btn);
   let pressbtn= btn.getAttribute("id");
   userSeq.push(pressbtn);
   check(userSeq.length-1);
}

let ALLbtn= document.querySelectorAll('.btn');
for(btn of ALLbtn){
    btn.addEventListener("click", btnPress);
}
